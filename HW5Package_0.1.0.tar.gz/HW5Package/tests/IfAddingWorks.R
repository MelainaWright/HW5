test_that("IfAddingWorks" ,
                           {

                             expect_that(Adding(x=6, y=4), equals(10))
                           })
